const bglist = {
    bg1: `url(./assets/bg-list/bg1.jpg)`,
    bg2: `url(./assets/bg-list/bg2.jpg)`,
    bg3: `url(./assets/bg-list/bg3.jpg)`,
    bg4:    `url(./assets/bg-list/bg4.jpg)`,
    bg5:    `url(./assets/bg-list/bg5.jpg)`,
    bg6:    `url(./assets/bg-list/bg6.jpg)`,
    bg7:    `url(./assets/bg-list/bg7.jpg)`,
    bg8:    `url(./assets/bg-list/bg8.jpg)`,
    bg9:   `url(./assets/bg-list/bg9.jpg)`,
    bg10:   `url(./assets/bg-list/bg10.jpg)`,
    bg11:   `url(./assets/bg-list/bg11.jpg)`,
    bg12:   `url(./assets/bg-list/bg12.jpg)`,
    bg13:   `url(./assets/bg-list/bg13.jpg)`,
    bg14:   `url(./assets/bg-list/bg14.jpg)`,
    bg15:   `url(./assets/bg-list/bg15.jpg)`,
    bg16:   `url(./assets/bg-list/bg16.jpg)`,
    bg17:   `url(./assets/bg-list/bg17.jpg)`,
    bg18:   `url(./assets/bg-list/bg18.jpg)`,
    bg19:   `url(./assets/bg-list/bg19.jpg)`,
    bg20:   `url(./assets/bg-list/bg20.jpg)`,
    bg21:   `url(./assets/bg-list/bg21.jpg)`,
    bg22:   `url(./assets/bg-list/bg22.jpg)`,
    bg23:   `url(./assets/bg-list/bg23.jpg)`,
    bg24:   `url(./assets/bg-list/bg24.jpg)`,
    bg25:    `url(./assets/bg-list/bg25.jpg)`
}


const backgrnd = document.querySelector('.container');

for(let key in bglist){
    console.log(key)
    setInterval((key)=>{
        backgrnd.style.background = `${bglist[key]}`;
        console.log(bglist[key])
    },2000);
}


